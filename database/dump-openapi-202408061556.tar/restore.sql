--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.2.24
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE openapi;
--
-- Name: openapi; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE openapi WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE openapi OWNER TO postgres;

\connect openapi

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: f_ins_tm_app_user_request_log(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.f_ins_tm_app_user_request_log() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	INSERT INTO public.tm_app_user_request_log
		("i_id"
          ,"i_id_app_user_request"
		  ,"i_id_user"
		  ,"n_requested_by"
		  ,"i_id_app_user"
		  ,"i_id_sit_type"
		  ,"n_doc_path"
		  ,"i_id_status"
		  ,"i_status_upd_by"
		  ,"d_status_upd_on"
		  ,"i_created_by"
		  ,"d_created_on"
		  ,"i_updated_by"
		  ,"d_updated_by"
		)
		VALUES
		(
            (SELECT i_cur_id FROM tr_nomax WHERE n_module_name = 'tm_app_user_request_log')
		  ,NEW."i_id"
		  ,NEW."i_id_user"
		  ,NEW."n_requested_by"
		  ,NEW."i_id_app_user"
		  ,NEW."i_id_sit_type"
		  ,NEW."n_doc_path"
		  ,NEW."i_id_status"
		  ,NEW."i_status_upd_by"
		  ,NEW."d_status_upd_on"
		  ,NEW."i_created_by"
		  ,NEW."d_created_on"
		  ,NEW."i_updated_by"
		  ,NEW."d_updated_by"
		)
	;
    UPDATE tr_nomax SET i_cur_id = i_cur_id + 1 WHERE n_module_name = 'tm_app_user_request_log';
	
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.f_ins_tm_app_user_request_log() OWNER TO postgres;

--
-- Name: f_upd_tm_app_user_request_log(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.f_upd_tm_app_user_request_log() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
	INSERT INTO public.tm_app_user_request_log
		("i_id"
          ,"i_id_app_user_request"
		  ,"i_id_user"
		  ,"n_requested_by"
		  ,"i_id_app_user"
		  ,"i_id_sit_type"
		  ,"n_doc_path"
		  ,"i_id_status"
		  ,"i_status_upd_by"
		  ,"d_status_upd_on"
		  ,"i_created_by"
		  ,"d_created_on"
		  ,"i_updated_by"
		  ,"d_updated_by"
		)
		VALUES
		(
            (SELECT i_cur_id FROM tr_nomax WHERE n_module_name = 'tm_app_user_request_log')
			  ,OLD."i_id"
			  ,OLD."i_id_user"
			  ,OLD."n_requested_by"
			  ,OLD."i_id_app_user"
			  ,OLD."i_id_sit_type"
			  ,OLD."n_doc_path"
			  ,OLD."i_id_status"
			  ,OLD."i_status_upd_by"
			  ,OLD."d_status_upd_on"
			  ,OLD."i_created_by"
			  ,OLD."d_created_on"
			  ,OLD."i_updated_by"
			  ,OLD."d_updated_by"
			)
	;
    UPDATE tr_nomax SET i_cur_id = i_cur_id + 1 WHERE n_module_name = 'tm_app_user_request_log';
		
		RETURN NEW;
	END;
	$$;


ALTER FUNCTION public.f_upd_tm_app_user_request_log() OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: tm_api_hit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_api_hit (
    i_id integer NOT NULL,
    i_id_api_katalog bigint NOT NULL,
    d_hit_date timestamp with time zone,
    c_external_id character varying(36) NOT NULL
);


ALTER TABLE public.tm_api_hit OWNER TO postgres;

--
-- Name: TABLE tm_api_hit; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_api_hit IS 'Log APi Hit';


--
-- Name: COLUMN tm_api_hit.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_api_hit.i_id IS 'ID';


--
-- Name: COLUMN tm_api_hit.i_id_api_katalog; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_api_hit.i_id_api_katalog IS 'Referenced from tr_api_katalog.i_id';


--
-- Name: COLUMN tm_api_hit.d_hit_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_api_hit.d_hit_date IS 'HIt Date';


--
-- Name: COLUMN tm_api_hit.c_external_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_api_hit.c_external_id IS 'External Unique Id';


--
-- Name: tm_app; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_app (
    i_id integer NOT NULL,
    n_name character varying(50) NOT NULL,
    n_version character varying(10),
    n_desc character varying(250),
    n_logo_path character varying(255),
    n_features character varying(1024),
    c_active character varying(1)
);


ALTER TABLE public.tm_app OWNER TO postgres;

--
-- Name: TABLE tm_app; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_app IS 'Application Properties';


--
-- Name: COLUMN tm_app.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app.i_id IS 'ID Application Properties';


--
-- Name: COLUMN tm_app.n_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app.n_name IS 'Application Name';


--
-- Name: COLUMN tm_app.n_version; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app.n_version IS 'Application Version';


--
-- Name: COLUMN tm_app.n_desc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app.n_desc IS 'Application Description';


--
-- Name: COLUMN tm_app.n_logo_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app.n_logo_path IS 'Application Logo Path';


--
-- Name: COLUMN tm_app.n_features; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app.n_features IS 'Update or features information (ex: if version is updated, etc)';


--
-- Name: COLUMN tm_app.c_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app.c_active IS 'Active Status';


--
-- Name: tm_app_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_app_user (
    i_id bigint NOT NULL,
    i_id_user bigint NOT NULL,
    n_app_name character varying(100) NOT NULL,
    i_app_type bigint,
    i_app_version bigint,
    n_source_acc character varying(50),
    i_max_hit_rate bigint,
    n_account_no character varying(100) NOT NULL,
    n_consumer_key character varying(100) NOT NULL,
    n_consumer_secret character varying(100) NOT NULL,
    c_active character varying(1) DEFAULT 1,
    i_created_by bigint DEFAULT 1,
    d_created_on timestamp with time zone DEFAULT now(),
    i_updated_by bigint,
    d_updated_by timestamp with time zone,
    d_max_hit_rate timestamp with time zone,
    i_count_hit_rate bigint
);


ALTER TABLE public.tm_app_user OWNER TO postgres;

--
-- Name: TABLE tm_app_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_app_user IS 'App User Relation';


--
-- Name: COLUMN tm_app_user.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.i_id IS 'ID App User';


--
-- Name: COLUMN tm_app_user.i_id_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.i_id_user IS 'ID User';


--
-- Name: COLUMN tm_app_user.n_app_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.n_app_name IS 'App Name';


--
-- Name: COLUMN tm_app_user.i_app_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.i_app_type IS 'Referenced from tr_literal.i_id App Type';


--
-- Name: COLUMN tm_app_user.i_app_version; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.i_app_version IS 'Referenced from tr_literal.i_id App Version';


--
-- Name: COLUMN tm_app_user.n_source_acc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.n_source_acc IS 'Source Account';


--
-- Name: COLUMN tm_app_user.i_max_hit_rate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.i_max_hit_rate IS 'Current Max Hit Rate';


--
-- Name: COLUMN tm_app_user.n_account_no; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.n_account_no IS 'Account No';


--
-- Name: COLUMN tm_app_user.n_consumer_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.n_consumer_key IS 'Consumer Key';


--
-- Name: COLUMN tm_app_user.n_consumer_secret; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.n_consumer_secret IS 'Consumer Secret';


--
-- Name: COLUMN tm_app_user.c_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.c_active IS 'Active Status';


--
-- Name: COLUMN tm_app_user.d_max_hit_rate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.d_max_hit_rate IS 'Current Hit Rate Last Valid Date';


--
-- Name: COLUMN tm_app_user.i_count_hit_rate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user.i_count_hit_rate IS 'Hit Rate Counter';


--
-- Name: tm_app_user_hit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_app_user_hit_log (
    i_id bigint NOT NULL,
    i_id_app_user bigint NOT NULL,
    i_max_hit_rate bigint,
    d_max_hit_rate timestamp with time zone,
    i_created_by bigint DEFAULT 1,
    d_created_on timestamp with time zone DEFAULT now(),
    i_updated_by bigint,
    d_updated_by timestamp with time zone,
    i_count_hit_rate bigint,
    c_active character varying(1)
);


ALTER TABLE public.tm_app_user_hit_log OWNER TO postgres;

--
-- Name: TABLE tm_app_user_hit_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_app_user_hit_log IS 'Log App User Hit Rate Max and Period';


--
-- Name: COLUMN tm_app_user_hit_log.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_hit_log.i_id IS 'ID';


--
-- Name: COLUMN tm_app_user_hit_log.i_id_app_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_hit_log.i_id_app_user IS 'Referenced from tm_app_user.i_id';


--
-- Name: COLUMN tm_app_user_hit_log.i_max_hit_rate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_hit_log.i_max_hit_rate IS 'Max Hit Rate Log';


--
-- Name: COLUMN tm_app_user_hit_log.d_max_hit_rate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_hit_log.d_max_hit_rate IS 'Hit Rate Last Valid Date Log';


--
-- Name: COLUMN tm_app_user_hit_log.i_count_hit_rate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_hit_log.i_count_hit_rate IS 'Hit Rate Last Counter';


--
-- Name: COLUMN tm_app_user_hit_log.c_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_hit_log.c_active IS 'Active Status';


--
-- Name: tm_app_user_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_app_user_product (
    i_id bigint NOT NULL,
    i_id_app_user bigint NOT NULL,
    i_id_app_product bigint NOT NULL,
    i_created_by bigint DEFAULT 1,
    d_created_by timestamp with time zone DEFAULT now(),
    i_updated_by bigint,
    d_updated_on timestamp with time zone,
    i_count_hit_rate bigint
);


ALTER TABLE public.tm_app_user_product OWNER TO postgres;

--
-- Name: TABLE tm_app_user_product; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_app_user_product IS 'App User and Product Relation';


--
-- Name: COLUMN tm_app_user_product.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_product.i_id IS 'ID App User Product';


--
-- Name: COLUMN tm_app_user_product.i_id_app_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_product.i_id_app_user IS 'Referenced from tm_app_user.i_id';


--
-- Name: COLUMN tm_app_user_product.i_id_app_product; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_product.i_id_app_product IS 'Referenced from tr_app_product.i_id';


--
-- Name: COLUMN tm_app_user_product.i_count_hit_rate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_product.i_count_hit_rate IS 'Hit Rate Counter';


--
-- Name: tm_app_user_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_app_user_request (
    i_id bigint NOT NULL,
    i_id_user bigint,
    n_requested_by character varying,
    i_id_app_user bigint NOT NULL,
    i_id_sit_type bigint,
    n_doc_path character varying(100),
    i_id_status bigint,
    i_status_upd_by bigint DEFAULT 1,
    d_status_upd_on timestamp with time zone DEFAULT now(),
    i_created_by bigint DEFAULT 1,
    d_created_on timestamp with time zone DEFAULT now(),
    i_updated_by bigint,
    d_updated_by timestamp with time zone
);


ALTER TABLE public.tm_app_user_request OWNER TO postgres;

--
-- Name: TABLE tm_app_user_request; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_app_user_request IS 'App SIT Request List';


--
-- Name: COLUMN tm_app_user_request.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request.i_id IS 'ID App User Request';


--
-- Name: COLUMN tm_app_user_request.i_id_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request.i_id_user IS 'Requestor (Person who request this). Referenced from tm_user.i_id';


--
-- Name: COLUMN tm_app_user_request.n_requested_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request.n_requested_by IS 'Requestor (Person who request this) if NOT from tm_user';


--
-- Name: COLUMN tm_app_user_request.i_id_app_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request.i_id_app_user IS 'Referenced from tm_app_user';


--
-- Name: COLUMN tm_app_user_request.i_id_sit_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request.i_id_sit_type IS 'Current SIT Type. Referenced from tr_literal.i_id SIT Type';


--
-- Name: COLUMN tm_app_user_request.n_doc_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request.n_doc_path IS 'Uploaded Document Path';


--
-- Name: COLUMN tm_app_user_request.i_id_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request.i_id_status IS 'Current SIT Request Status. Referenced from tr_literal.i_id SIT Request Status';


--
-- Name: COLUMN tm_app_user_request.i_status_upd_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request.i_status_upd_by IS 'Person who update Status. Referenced from tm_user.i_id';


--
-- Name: COLUMN tm_app_user_request.d_status_upd_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request.d_status_upd_on IS 'DateTime on SIT-Request-Status Changed';


--
-- Name: tm_app_user_request_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_app_user_request_log (
    i_id bigint NOT NULL,
    i_id_app_user_request bigint,
    i_id_user bigint,
    n_requested_by character varying,
    i_id_app_user bigint NOT NULL,
    i_id_sit_type bigint,
    n_doc_path character varying(100),
    i_id_status bigint,
    i_status_upd_by bigint DEFAULT 1,
    d_status_upd_on timestamp with time zone DEFAULT now(),
    i_created_by bigint DEFAULT 1,
    d_created_on timestamp with time zone DEFAULT now(),
    i_updated_by bigint,
    d_updated_by timestamp with time zone
);


ALTER TABLE public.tm_app_user_request_log OWNER TO postgres;

--
-- Name: TABLE tm_app_user_request_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_app_user_request_log IS 'App SIT Request Log';


--
-- Name: COLUMN tm_app_user_request_log.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request_log.i_id IS 'ID App User Request Log';


--
-- Name: COLUMN tm_app_user_request_log.i_id_app_user_request; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request_log.i_id_app_user_request IS 'ID App User Request';


--
-- Name: COLUMN tm_app_user_request_log.i_id_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request_log.i_id_user IS 'Requestor (Person who request this). Referenced from tm_user.i_id';


--
-- Name: COLUMN tm_app_user_request_log.n_requested_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request_log.n_requested_by IS 'Requestor (Person who request this) if NOT from tm_user';


--
-- Name: COLUMN tm_app_user_request_log.i_id_app_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request_log.i_id_app_user IS 'Referenced from tm_app_user';


--
-- Name: COLUMN tm_app_user_request_log.i_id_sit_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request_log.i_id_sit_type IS 'Current SIT Type. Referenced from tr_literal.i_id SIT Type';


--
-- Name: COLUMN tm_app_user_request_log.n_doc_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request_log.n_doc_path IS 'Uploaded Document Path';


--
-- Name: COLUMN tm_app_user_request_log.i_id_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request_log.i_id_status IS 'Current SIT Request Status. Referenced from tr_literal.i_id SIT Request Status';


--
-- Name: COLUMN tm_app_user_request_log.i_status_upd_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request_log.i_status_upd_by IS 'Person who update Status. Referenced from tm_user.i_id';


--
-- Name: COLUMN tm_app_user_request_log.d_status_upd_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_app_user_request_log.d_status_upd_on IS 'DateTime on SIT-Request-Status Changed';


--
-- Name: tm_authority_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_authority_menu (
    i_id integer NOT NULL,
    i_id_authority integer NOT NULL,
    i_id_menu integer NOT NULL,
    i_created_by bigint DEFAULT (1)::bigint NOT NULL,
    d_created_on timestamp with time zone DEFAULT now() NOT NULL,
    i_updated_by bigint,
    d_updated_on timestamp with time zone
);


ALTER TABLE public.tm_authority_menu OWNER TO postgres;

--
-- Name: TABLE tm_authority_menu; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_authority_menu IS 'Authority and Menu Relation';


--
-- Name: COLUMN tm_authority_menu.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_authority_menu.i_id IS 'ID Authority Menu';


--
-- Name: COLUMN tm_authority_menu.i_id_authority; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_authority_menu.i_id_authority IS 'Referenced from tr_authority.i_id';


--
-- Name: COLUMN tm_authority_menu.i_id_menu; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_authority_menu.i_id_menu IS 'Referenced from tr_menu.i_id';


--
-- Name: tm_cms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_cms (
    i_id bigint NOT NULL,
    i_id_parent bigint,
    i_id_authority_for integer,
    i_id_cms_type bigint,
    n_title character varying(100) NOT NULL,
    n_link_url character varying(100),
    n_image character varying(100),
    n_content text,
    c_active character varying(1),
    d_start_date timestamp with time zone,
    d_end_date timestamp with time zone,
    i_created_by bigint DEFAULT (1)::bigint NOT NULL,
    d_created_on timestamp with time zone DEFAULT now() NOT NULL,
    i_updated_by bigint,
    d_updated_on timestamp with time zone,
    n_image_src bytea,
    n_bucket character varying
);


ALTER TABLE public.tm_cms OWNER TO postgres;

--
-- Name: TABLE tm_cms; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_cms IS 'CMS List';


--
-- Name: COLUMN tm_cms.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.i_id IS 'ID CMS';


--
-- Name: COLUMN tm_cms.i_id_parent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.i_id_parent IS 'ID Parent CMS';


--
-- Name: COLUMN tm_cms.i_id_authority_for; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.i_id_authority_for IS 'Consumption For (1 = Admin; 2 = Tenant)';


--
-- Name: COLUMN tm_cms.i_id_cms_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.i_id_cms_type IS 'ID CMS Type. Referenced from tr_literal.i_id CMS Type';


--
-- Name: COLUMN tm_cms.n_title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.n_title IS 'Title';


--
-- Name: COLUMN tm_cms.n_link_url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.n_link_url IS 'Link';


--
-- Name: COLUMN tm_cms.n_image; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.n_image IS 'Image';


--
-- Name: COLUMN tm_cms.n_content; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.n_content IS 'Content';


--
-- Name: COLUMN tm_cms.c_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.c_active IS 'Active Status';


--
-- Name: COLUMN tm_cms.d_start_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.d_start_date IS 'Start Date';


--
-- Name: COLUMN tm_cms.d_end_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.d_end_date IS 'End Date';


--
-- Name: COLUMN tm_cms.n_image_src; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_cms.n_image_src IS 'Source Image';


--
-- Name: tm_sig_gen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_sig_gen (
    i_id bigint NOT NULL,
    i_id_user bigint NOT NULL,
    i_id_api_version bigint,
    i_id_api_type bigint,
    i_id_api_method bigint,
    n_url_path character varying(100),
    d_timestamp timestamp with time zone,
    n_client_id character varying(100),
    n_client_secret character varying(100),
    n_body character varying(100),
    n_access_token character varying(100),
    n_signature_result character varying(100),
    i_created_by bigint DEFAULT 1,
    d_created_on timestamp with time zone DEFAULT now(),
    i_updated_by bigint,
    d_updated_on timestamp with time zone
);


ALTER TABLE public.tm_sig_gen OWNER TO postgres;

--
-- Name: TABLE tm_sig_gen; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_sig_gen IS 'Signature Generation List';


--
-- Name: COLUMN tm_sig_gen.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.i_id IS 'ID Signature Generation';


--
-- Name: COLUMN tm_sig_gen.i_id_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.i_id_user IS 'Referenced from tm_user.i_id';


--
-- Name: COLUMN tm_sig_gen.i_id_api_version; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.i_id_api_version IS 'Referenced from tr_literal.i_id API Version';


--
-- Name: COLUMN tm_sig_gen.i_id_api_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.i_id_api_type IS 'Referenced from tr_literal.i_id API Type';


--
-- Name: COLUMN tm_sig_gen.i_id_api_method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.i_id_api_method IS 'Referenced from tr_literal.i_id API Method';


--
-- Name: COLUMN tm_sig_gen.n_url_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.n_url_path IS 'URL Path';


--
-- Name: COLUMN tm_sig_gen.d_timestamp; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.d_timestamp IS 'Timestamp';


--
-- Name: COLUMN tm_sig_gen.n_client_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.n_client_id IS 'Client Id';


--
-- Name: COLUMN tm_sig_gen.n_client_secret; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.n_client_secret IS 'Client Secret';


--
-- Name: COLUMN tm_sig_gen.n_body; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.n_body IS 'Body';


--
-- Name: COLUMN tm_sig_gen.n_access_token; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.n_access_token IS 'Access Token';


--
-- Name: COLUMN tm_sig_gen.n_signature_result; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_sig_gen.n_signature_result IS 'Signature Result';


--
-- Name: tm_upstream; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_upstream (
    i_id integer NOT NULL,
    n_name character varying(250),
    n_description character varying(1000),
    n_config character varying(8000),
    created_by integer,
    created_on timestamp with time zone,
    updated_by integer,
    updated_on timestamp with time zone
);


ALTER TABLE public.tm_upstream OWNER TO postgres;

--
-- Name: COLUMN tm_upstream.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_upstream.i_id IS 'ID Upstream';


--
-- Name: COLUMN tm_upstream.n_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_upstream.n_name IS 'Name';


--
-- Name: COLUMN tm_upstream.n_description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_upstream.n_description IS 'Description';


--
-- Name: COLUMN tm_upstream.n_config; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_upstream.n_config IS 'Config';


--
-- Name: tm_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_user (
    i_id bigint NOT NULL,
    n_name character varying(100) NOT NULL,
    n_surname character varying(100),
    n_username character varying(100) NOT NULL,
    n_password character varying(255) NOT NULL,
    n_email character varying(50),
    n_phone character varying(50),
    n_company character varying(50),
    n_address character varying(250),
    c_active character varying(1) DEFAULT 1,
    i_created_by bigint DEFAULT 1,
    d_created_on timestamp with time zone DEFAULT now(),
    i_updated_by bigint,
    d_updated_on timestamp with time zone,
    i_partner_id character varying(40)
);


ALTER TABLE public.tm_user OWNER TO postgres;

--
-- Name: TABLE tm_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_user IS 'User List';


--
-- Name: COLUMN tm_user.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user.i_id IS 'ID User';


--
-- Name: COLUMN tm_user.n_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user.n_name IS 'Name';


--
-- Name: COLUMN tm_user.n_surname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user.n_surname IS 'Surname';


--
-- Name: COLUMN tm_user.n_username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user.n_username IS 'Username';


--
-- Name: COLUMN tm_user.n_password; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user.n_password IS 'Password';


--
-- Name: COLUMN tm_user.n_email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user.n_email IS 'Email';


--
-- Name: COLUMN tm_user.n_phone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user.n_phone IS 'Phone';


--
-- Name: COLUMN tm_user.n_company; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user.n_company IS 'Company';


--
-- Name: COLUMN tm_user.n_address; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user.n_address IS 'Address';


--
-- Name: COLUMN tm_user.c_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user.c_active IS 'Active Status';


--
-- Name: tm_user_authority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_user_authority (
    i_id integer NOT NULL,
    i_id_user bigint NOT NULL,
    i_id_authority integer NOT NULL,
    i_created_by bigint DEFAULT (1)::bigint NOT NULL,
    d_created_on timestamp with time zone DEFAULT now() NOT NULL,
    i_updated_by bigint,
    d_updated_on timestamp with time zone
);


ALTER TABLE public.tm_user_authority OWNER TO postgres;

--
-- Name: TABLE tm_user_authority; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_user_authority IS 'User and Authority Relation';


--
-- Name: COLUMN tm_user_authority.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user_authority.i_id IS 'ID User Authority';


--
-- Name: COLUMN tm_user_authority.i_id_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user_authority.i_id_user IS 'Referenced from tm_user.i_id';


--
-- Name: COLUMN tm_user_authority.i_id_authority; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user_authority.i_id_authority IS 'Referenced from tm_authority.i_id';


--
-- Name: tm_user_key; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tm_user_key (
    i_id bigint NOT NULL,
    i_id_user bigint NOT NULL,
    private_key character varying NOT NULL,
    public_key character varying NOT NULL,
    c_active character varying(1) DEFAULT 1,
    i_created_by bigint DEFAULT 1,
    d_created_on timestamp with time zone DEFAULT now(),
    i_updated_by bigint,
    d_updated_on timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tm_user_key OWNER TO postgres;

--
-- Name: TABLE tm_user_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tm_user_key IS 'User Key List';


--
-- Name: COLUMN tm_user_key.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user_key.i_id IS 'ID User Key';


--
-- Name: COLUMN tm_user_key.i_id_user; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user_key.i_id_user IS 'Referenced from tm_user.i_id';


--
-- Name: COLUMN tm_user_key.private_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user_key.private_key IS 'User Private Key';


--
-- Name: COLUMN tm_user_key.public_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user_key.public_key IS 'User Public Key';


--
-- Name: COLUMN tm_user_key.c_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tm_user_key.c_active IS 'Active Status';


--
-- Name: tr_api_katalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tr_api_katalog (
    i_id integer NOT NULL,
    i_id_api_method bigint NOT NULL,
    n_name character varying(100) NOT NULL,
    n_category character varying(100),
    n_description character varying(512),
    n_url character varying(100),
    n_path_doc character varying(100),
    created_by integer DEFAULT 1 NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_by integer,
    updated_on timestamp with time zone,
    request_header character varying,
    request_body character varying,
    header_schema character varying,
    body_schema character varying,
    status smallint,
    i_id_induk integer,
    n_config_route character varying(8000),
    n_title character varying(100),
    n_path_picture character varying(1000),
    i_id_upstream integer,
    is_snap smallint
);


ALTER TABLE public.tr_api_katalog OWNER TO postgres;

--
-- Name: TABLE tr_api_katalog; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tr_api_katalog IS 'Reference(s) Data of API Catalog';


--
-- Name: COLUMN tr_api_katalog.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.i_id IS 'ID API Catalog';


--
-- Name: COLUMN tr_api_katalog.i_id_api_method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.i_id_api_method IS 'Referenced from tr_literal.i_id API Method';


--
-- Name: COLUMN tr_api_katalog.n_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.n_name IS 'Name';


--
-- Name: COLUMN tr_api_katalog.n_category; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.n_category IS 'Category';


--
-- Name: COLUMN tr_api_katalog.n_description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.n_description IS 'Description';


--
-- Name: COLUMN tr_api_katalog.n_url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.n_url IS 'URL';


--
-- Name: COLUMN tr_api_katalog.n_path_doc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.n_path_doc IS 'Document Path';


--
-- Name: COLUMN tr_api_katalog.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.status IS 'Status';


--
-- Name: COLUMN tr_api_katalog.n_config_route; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.n_config_route IS 'Route Config';


--
-- Name: COLUMN tr_api_katalog.n_title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.n_title IS 'Title';


--
-- Name: COLUMN tr_api_katalog.n_path_picture; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.n_path_picture IS 'Picture Path';


--
-- Name: COLUMN tr_api_katalog.i_id_upstream; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_api_katalog.i_id_upstream IS 'Referenced from tm_upstream.i_id';


--
-- Name: tr_app_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tr_app_product (
    i_id bigint NOT NULL,
    n_name character varying(100) NOT NULL,
    n_description character varying(250),
    i_created_by bigint DEFAULT 1,
    d_created_on timestamp with time zone DEFAULT now(),
    i_updated_by bigint,
    d_updated_on timestamp with time zone
);


ALTER TABLE public.tr_app_product OWNER TO postgres;

--
-- Name: TABLE tr_app_product; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tr_app_product IS 'App Products References Data';


--
-- Name: COLUMN tr_app_product.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_app_product.i_id IS 'ID App Product';


--
-- Name: COLUMN tr_app_product.n_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_app_product.n_name IS 'Product Name';


--
-- Name: COLUMN tr_app_product.n_description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_app_product.n_description IS 'Product Description';


--
-- Name: tr_authority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tr_authority (
    i_id integer NOT NULL,
    n_auth_name character varying(50) NOT NULL,
    i_created_by bigint DEFAULT (1)::bigint NOT NULL,
    d_created_on timestamp with time zone DEFAULT now() NOT NULL,
    i_updated_by bigint,
    d_updated_on timestamp with time zone
);


ALTER TABLE public.tr_authority OWNER TO postgres;

--
-- Name: TABLE tr_authority; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tr_authority IS 'Authority References Data';


--
-- Name: COLUMN tr_authority.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_authority.i_id IS 'ID Authority';


--
-- Name: COLUMN tr_authority.n_auth_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_authority.n_auth_name IS 'Authority Name';


--
-- Name: tr_literal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tr_literal (
    i_id bigint NOT NULL,
    n_category character varying(50) NOT NULL,
    n_name character varying(250) NOT NULL,
    e_description character varying(500),
    i_order smallint,
    c_active character varying(1),
    i_created_by bigint DEFAULT (1)::bigint NOT NULL,
    d_created_on timestamp with time zone DEFAULT now() NOT NULL,
    i_updated_by bigint,
    d_updated_on timestamp with time zone
);


ALTER TABLE public.tr_literal OWNER TO postgres;

--
-- Name: TABLE tr_literal; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tr_literal IS 'Literal References Data';


--
-- Name: COLUMN tr_literal.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_literal.i_id IS 'ID Literal';


--
-- Name: COLUMN tr_literal.n_category; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_literal.n_category IS 'Category';


--
-- Name: COLUMN tr_literal.n_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_literal.n_name IS 'Name';


--
-- Name: COLUMN tr_literal.e_description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_literal.e_description IS 'Description';


--
-- Name: COLUMN tr_literal.i_order; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_literal.i_order IS 'Order';


--
-- Name: COLUMN tr_literal.c_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_literal.c_active IS 'Active Status';


--
-- Name: tr_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tr_menu (
    i_id integer NOT NULL,
    i_id_parent integer,
    n_name character varying(50) NOT NULL,
    n_desc character varying(100),
    n_link character varying(100),
    n_image character varying(100),
    c_active character varying(1),
    i_created_by bigint DEFAULT (1)::bigint NOT NULL,
    d_created_on timestamp with time zone DEFAULT now() NOT NULL,
    i_updated_by bigint,
    d_updated_on timestamp with time zone,
    c_logged_in character varying(1) DEFAULT 0 NOT NULL
);


ALTER TABLE public.tr_menu OWNER TO postgres;

--
-- Name: TABLE tr_menu; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tr_menu IS 'Menu References Data';


--
-- Name: COLUMN tr_menu.i_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_menu.i_id IS 'ID Menu';


--
-- Name: COLUMN tr_menu.i_id_parent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_menu.i_id_parent IS 'ID Parent Menu';


--
-- Name: COLUMN tr_menu.n_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_menu.n_name IS 'Name';


--
-- Name: COLUMN tr_menu.n_desc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_menu.n_desc IS 'Description';


--
-- Name: COLUMN tr_menu.n_link; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_menu.n_link IS 'Link';


--
-- Name: COLUMN tr_menu.n_image; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_menu.n_image IS 'Image';


--
-- Name: COLUMN tr_menu.c_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tr_menu.c_active IS 'Active Status';


--
-- Name: tr_nomax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tr_nomax (
    i_id smallint NOT NULL,
    n_module_name character varying(50) NOT NULL,
    i_cur_id bigint NOT NULL,
    i_created_by bigint DEFAULT (1)::bigint NOT NULL,
    d_created_on timestamp with time zone DEFAULT now() NOT NULL,
    i_updated_by bigint,
    d_updated_on timestamp with time zone
);


ALTER TABLE public.tr_nomax OWNER TO postgres;

--
-- Data for Name: tm_api_hit; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3063.dat

--
-- Data for Name: tm_app; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3060.dat

--
-- Data for Name: tm_app_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3055.dat

--
-- Data for Name: tm_app_user_hit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3061.dat

--
-- Data for Name: tm_app_user_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3051.dat

--
-- Data for Name: tm_app_user_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3058.dat

--
-- Data for Name: tm_app_user_request_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3059.dat

--
-- Data for Name: tm_authority_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3046.dat

--
-- Data for Name: tm_cms; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3056.dat

--
-- Data for Name: tm_sig_gen; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3052.dat

--
-- Data for Name: tm_upstream; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3062.dat

--
-- Data for Name: tm_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3050.dat

--
-- Data for Name: tm_user_authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3047.dat

--
-- Data for Name: tm_user_key; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3053.dat

--
-- Data for Name: tr_api_katalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3057.dat

--
-- Data for Name: tr_app_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3049.dat

--
-- Data for Name: tr_authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3044.dat

--
-- Data for Name: tr_literal; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3048.dat

--
-- Data for Name: tr_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3045.dat

--
-- Data for Name: tr_nomax; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3054.dat

--
-- Name: tm_api_hit tm_api_hit_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_api_hit
    ADD CONSTRAINT tm_api_hit_pk PRIMARY KEY (i_id);


--
-- Name: tm_app tm_app_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app
    ADD CONSTRAINT tm_app_pk PRIMARY KEY (i_id);


--
-- Name: tm_app_user_hit_log tm_app_user_hit_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user_hit_log
    ADD CONSTRAINT tm_app_user_hit_pk PRIMARY KEY (i_id);


--
-- Name: tm_app_user tm_app_user_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user
    ADD CONSTRAINT tm_app_user_pk PRIMARY KEY (i_id);


--
-- Name: tm_app_user_product tm_app_user_product_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user_product
    ADD CONSTRAINT tm_app_user_product_pk PRIMARY KEY (i_id);


--
-- Name: tm_app_user_request_log tm_app_user_request_log_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user_request_log
    ADD CONSTRAINT tm_app_user_request_log_pk PRIMARY KEY (i_id);


--
-- Name: tm_app_user_request tm_app_user_request_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user_request
    ADD CONSTRAINT tm_app_user_request_pk PRIMARY KEY (i_id);


--
-- Name: tm_app_user tm_app_user_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user
    ADD CONSTRAINT tm_app_user_unique UNIQUE (n_app_name);


--
-- Name: tm_authority_menu tm_authority_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_authority_menu
    ADD CONSTRAINT tm_authority_menu_pkey PRIMARY KEY (i_id);


--
-- Name: tm_sig_gen tm_sig_gen_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_sig_gen
    ADD CONSTRAINT tm_sig_gen_pk PRIMARY KEY (i_id);


--
-- Name: tm_upstream tm_upstream_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_upstream
    ADD CONSTRAINT tm_upstream_pk PRIMARY KEY (i_id);


--
-- Name: tm_user tm_user_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user
    ADD CONSTRAINT tm_user_email_unique UNIQUE (n_email);


--
-- Name: tm_user_key tm_user_key_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user_key
    ADD CONSTRAINT tm_user_key_pk PRIMARY KEY (i_id);


--
-- Name: tm_user_key tm_user_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user_key
    ADD CONSTRAINT tm_user_key_unique UNIQUE (private_key);


--
-- Name: tm_user_key tm_user_key_unique_1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user_key
    ADD CONSTRAINT tm_user_key_unique_1 UNIQUE (public_key);


--
-- Name: tm_user tm_user_phone_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user
    ADD CONSTRAINT tm_user_phone_unique UNIQUE (n_phone);


--
-- Name: tm_user tm_user_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user
    ADD CONSTRAINT tm_user_pk PRIMARY KEY (i_id);


--
-- Name: tm_user tm_user_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user
    ADD CONSTRAINT tm_user_unique UNIQUE (n_username);


--
-- Name: tm_user_authority tm_user_web_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user_authority
    ADD CONSTRAINT tm_user_web_authority_pkey PRIMARY KEY (i_id);


--
-- Name: tr_api_katalog tr_api_katalog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tr_api_katalog
    ADD CONSTRAINT tr_api_katalog_pkey PRIMARY KEY (i_id);


--
-- Name: tr_app_product tr_app_product_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tr_app_product
    ADD CONSTRAINT tr_app_product_pk PRIMARY KEY (i_id);


--
-- Name: tr_authority tr_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tr_authority
    ADD CONSTRAINT tr_authority_pkey PRIMARY KEY (i_id);


--
-- Name: tr_authority tr_authority_unique1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tr_authority
    ADD CONSTRAINT tr_authority_unique1 UNIQUE (n_auth_name);


--
-- Name: tm_cms tr_cms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_cms
    ADD CONSTRAINT tr_cms_pkey PRIMARY KEY (i_id);


--
-- Name: tr_literal tr_literal_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tr_literal
    ADD CONSTRAINT tr_literal_pk PRIMARY KEY (i_id);


--
-- Name: tr_menu tr_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tr_menu
    ADD CONSTRAINT tr_menu_pkey PRIMARY KEY (i_id);


--
-- Name: tr_nomax tr_nomax_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tr_nomax
    ADD CONSTRAINT tr_nomax_pkey PRIMARY KEY (i_id);


--
-- Name: tr_nomax tr_nomax_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tr_nomax
    ADD CONSTRAINT tr_nomax_un UNIQUE (n_module_name);


--
-- Name: tr_literal_n_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tr_literal_n_category_idx ON public.tr_literal USING btree (n_category);


--
-- Name: tm_api_hit tm_api_hit_tr_api_katalog_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_api_hit
    ADD CONSTRAINT tm_api_hit_tr_api_katalog_fk FOREIGN KEY (i_id_api_katalog) REFERENCES public.tr_api_katalog(i_id);


--
-- Name: tm_app_user_hit_log tm_app_user_hit_tm_app_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user_hit_log
    ADD CONSTRAINT tm_app_user_hit_tm_app_user_fk FOREIGN KEY (i_id_app_user) REFERENCES public.tm_app_user(i_id);


--
-- Name: tm_app_user_product tm_app_user_product_tm_app_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user_product
    ADD CONSTRAINT tm_app_user_product_tm_app_user_fk FOREIGN KEY (i_id_app_user) REFERENCES public.tm_app_user(i_id);


--
-- Name: tm_app_user_request tm_app_user_request_tm_app_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user_request
    ADD CONSTRAINT tm_app_user_request_tm_app_user_fk FOREIGN KEY (i_id_app_user) REFERENCES public.tm_app_user(i_id);


--
-- Name: tm_app_user_request tm_app_user_request_tm_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user_request
    ADD CONSTRAINT tm_app_user_request_tm_user_fk FOREIGN KEY (i_id_user) REFERENCES public.tm_user(i_id);


--
-- Name: tm_app_user_request tm_app_user_request_tr_literal_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user_request
    ADD CONSTRAINT tm_app_user_request_tr_literal_fk FOREIGN KEY (i_id_status) REFERENCES public.tr_literal(i_id);


--
-- Name: tm_app_user_request tm_app_user_request_tr_literal_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user_request
    ADD CONSTRAINT tm_app_user_request_tr_literal_fk2 FOREIGN KEY (i_id_sit_type) REFERENCES public.tr_literal(i_id);


--
-- Name: tm_app_user tm_app_user_tm_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_app_user
    ADD CONSTRAINT tm_app_user_tm_user_fk FOREIGN KEY (i_id_user) REFERENCES public.tm_user(i_id);


--
-- Name: tm_authority_menu tm_authority_menu_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_authority_menu
    ADD CONSTRAINT tm_authority_menu_fk FOREIGN KEY (i_id_authority) REFERENCES public.tr_authority(i_id);


--
-- Name: tm_authority_menu tm_authority_menu_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_authority_menu
    ADD CONSTRAINT tm_authority_menu_fk_1 FOREIGN KEY (i_id_menu) REFERENCES public.tr_menu(i_id);


--
-- Name: tm_cms tm_cms_tr_literal_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_cms
    ADD CONSTRAINT tm_cms_tr_literal_fk FOREIGN KEY (i_id_cms_type) REFERENCES public.tr_literal(i_id);


--
-- Name: tm_sig_gen tm_sig_gen_tm_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_sig_gen
    ADD CONSTRAINT tm_sig_gen_tm_user_fk FOREIGN KEY (i_id_user) REFERENCES public.tm_user(i_id);


--
-- Name: tm_sig_gen tm_sig_gen_tr_literal_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_sig_gen
    ADD CONSTRAINT tm_sig_gen_tr_literal_fk FOREIGN KEY (i_id_api_version) REFERENCES public.tr_literal(i_id);


--
-- Name: tm_sig_gen tm_sig_gen_tr_literal_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_sig_gen
    ADD CONSTRAINT tm_sig_gen_tr_literal_fk_1 FOREIGN KEY (i_id_api_type) REFERENCES public.tr_literal(i_id);


--
-- Name: tm_sig_gen tm_sig_gen_tr_literal_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_sig_gen
    ADD CONSTRAINT tm_sig_gen_tr_literal_fk_2 FOREIGN KEY (i_id_api_method) REFERENCES public.tr_literal(i_id);


--
-- Name: tm_user_authority tm_user_authority_tm_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user_authority
    ADD CONSTRAINT tm_user_authority_tm_user_fk FOREIGN KEY (i_id_user) REFERENCES public.tm_user(i_id);


--
-- Name: tm_user_authority tm_user_authority_tr_authority_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user_authority
    ADD CONSTRAINT tm_user_authority_tr_authority_fk FOREIGN KEY (i_id_authority) REFERENCES public.tr_authority(i_id);


--
-- Name: tm_user_key tm_user_key_tm_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tm_user_key
    ADD CONSTRAINT tm_user_key_tm_user_fk FOREIGN KEY (i_id_user) REFERENCES public.tm_user(i_id);


--
-- Name: tr_api_katalog tr_api_katalog_tm_upstream_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tr_api_katalog
    ADD CONSTRAINT tr_api_katalog_tm_upstream_fk FOREIGN KEY (i_id_upstream) REFERENCES public.tm_upstream(i_id);


--
-- Name: tr_api_katalog tr_api_katalog_tr_literal_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tr_api_katalog
    ADD CONSTRAINT tr_api_katalog_tr_literal_fk FOREIGN KEY (i_id_api_method) REFERENCES public.tr_literal(i_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

